# NamoWarriors - Chat
## Made in AatmaNirbhar India

# Advantages of using NamoWarriors:
1) Made in love with India.
2) Fully secure and encrypted data transfer using RSA.
3) Get regular news updates from the best news anchors of the country.
